# GATE 2027 — My Journey

A free, GitHub Pages-ready personal GATE ECE preparation dashboard.

## Features
- Dashboard and GATE countdown
- Daily tasks and streak
- Subject syllabus + accuracy tracking
- Notes/PDF resource index + official GATE PYQ archive links (2007–2025) + older-paper archive link + online mock sources
- Formula vault
- PYQ tracker
- Mistake book
- Revision scheduler
- Timetable
- Mock-test tracker
- 7-day analytics
- Local browser storage

## Run
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Create a GitHub repository, e.g. `gate-2027`.
2. Upload `index.html` and this README.
3. Go to Settings → Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the public website URL.

## PYQ and mock-test sources
The site links out to official/hosted sources rather than bundling copyrighted PDFs into the repository. It includes:
- Official GATE 2025 archive: 2007–2024 bulk/year-wise papers
- Official GATE 2025 master question-paper/key page
- GATE Overflow ECE historical archive and online original-paper tests
- Testbook GATE ECE mock/PYP test series

## Important
This first version stores your data in the browser's localStorage. It does not upload files to a server. For cloud sync, login, real PDF uploads, and access from multiple devices, add a free backend such as Supabase or Firebase in the next version.
